export const Menu = [
  {
      id: 1,
      name: "Home",
      link: "/"
  },
  {
      id: 2,
      name: "Concerts",
      link: "/concerts"
  },
  {
      id: 3,
      name: "Favorites",
      link: "/favorites"
  },
  {
    id: 4,
    name: "Cart",
    link: "/cart"
  },
  {
      id: 5,
      name: "About",
      link: "/about"
  }
]

export const { upcomingConcerts, pastConcerts } = {
  upcomingConcerts: [
    {
      id: 1,
      name: "Rock Fest",
      date: "2024-04-15",
      time: "7:00 PM",
      location: "City Arena",
      details: "A night of rock music featuring top bands.",
      genre: "Rock",
      price: "$50",
    },
    {
      id: 2,
      name: "Jazz Night",
      date: "2024-05-10",
      time: "8:00 PM",
      location: "Downtown Jazz Club",
      details: "Smooth jazz performances by renowned artists.",
      genre: "Jazz",
      price: "$40",
    },
    {
      id: 3,
      name: "Pop Extravaganza",
      date: "2024-06-05",
      time: "6:30 PM",
      location: "Main Concert Hall",
      details: "A spectacular pop music concert.",
      genre: "Pop",
      price: "$60",
    },
    {
      id: 4,
      name: "Classical Evening",
      date: "2024-07-15",
      time: "5:00 PM",
      location: "Grand Theater",
      details: "An evening of classical music by the city orchestra.",
      genre: "Classical",
      price: "$70",
    },
    {
      id: 5,
      name: "Hip-Hop Bash",
      date: "2024-08-12",
      time: "9:00 PM",
      location: "Urban Arena",
      details: "A night of hip-hop music and dance.",
      genre: "Hip-Hop",
      price: "$55",
    },
  ],
  pastConcerts: [
    {
      id: 1,
      name: "Blues Festival",
      date: "2024-03-20",
      location: "Open Air Theater",
      results: "Amazing performances by top blues artists.",
      genre: "Blues",
      price: "$45",
    },
    {
      id: 2,
      name: "Indie Rock Night",
      date: "2024-02-28",
      location: "City Arena",
      results: "Indie bands rocked the stage.",
      genre: "Indie Rock",
      price: "$35",
    },
    {
      id: 3,
      name: "Electronic Dance Party",
      date: "2024-01-15",
      location: "Downtown Club",
      results: "A night of non-stop electronic dance music.",
      genre: "EDM",
      price: "$50",
    },
    {
      id: 4,
      name: "Folk Music Gathering",
      date: "2023-12-05",
      location: "Community Center",
      results: "Folk music enthusiasts enjoyed a great evening.",
      genre: "Folk",
      price: "$30",
    },
    {
      id: 5,
      name: "Reggae Vibes",
      date: "2023-11-12",
      location: "Beachside Stage",
      results: "Reggae bands brought the beach to life.",
      genre: "Reggae",
      price: "$40",
    },
    {
      id: 6,
      name: "Metal Mania",
      date: "2023-10-05",
      location: "City Arena",
      results: "Metal bands delivered powerful performances.",
      genre: "Metal",
      price: "$60",
    },
  ],
  
};

export const cart = [
  {
    id: 1,
    name: "Rock Fest Ticket",
    quantity: 2,
    price: "$50",
  },
  {
    id: 2,
    name: "Jazz Night Ticket",
    quantity: 1,
    price: "$40",
  },
  {
    id: 3,
    name: "Pop Extravaganza Ticket",
    quantity: 3,
    price: "$60",
  },
  // Add more items as needed
];