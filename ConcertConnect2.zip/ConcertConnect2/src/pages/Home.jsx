import ConcertVid from "../assets/videos/ConcertVid.mp4";
import Hero from "../components/Hero/Hero";

const Home = () => {
    return (
        <div>
            <div className="relative h-[700px]">
            <video 
                    autoPlay 
                    muted 
                    loop 
                    className="absolute right-0 top-0 h-[700px] w-full object-cover z-[-1]"
                >
                    <source src={ConcertVid} type="video/mp4"/>
            </video>
            </div>
            <Hero />
        </div>
    );
    }

export default Home;