import Logo from "../../assets/images/logo.png";
import { Menu } from "../../data/Data";


const Navbar = () => {
  return (
    <div>
        <div>
            <div className="container flex justify-between items-center">
                <div>
                    <a href="#" className="font-bold text-2xl sm:text-3xl flex gap-2">
                    <img src={Logo} alt="Logo" className="w-16" />
                    ConcertConnect
                    </a>
                </div>

                <div className="flex items-end space-x-4">
                    <button
                        type="button"
                        className="bg-secondary text-white px-4 py-2 rounded-md"
                    >
                        Sign Up
                    </button>
                    <button
                        type="button"
                        className="bg-secondary text-white px-4 py-2 rounded-md"
                    >
                        Log in
                    </button>
                </div>
            </div>
        </div>
        <div className="bg-primary/40 py-4 flex justify-center">
            <ul className="sm:flex hidden items-center gap-4">
                {
                Menu.map((data)=>(
                    <li key={data.id}>
                        <a 
                        href={data.link}
                        className="inline-block px-4 text-white hover:text-secondary transition duration-200"
                        >
                            {data.name}</a>
                    </li>
                ))
                }     
            </ul> 
        </div>
    </div>
  );
}

export default Navbar;